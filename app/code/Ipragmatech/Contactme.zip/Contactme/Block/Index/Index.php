<?php
/**
 * Copyright © 2015 Ipragmatech . All rights reserved.
 */
namespace Ipragmatech\Contactme\Block\Index;
use Ipragmatech\Contactme\Block\BaseBlock;
class Index extends BaseBlock
{
	public $hello='Hello World';
	
}
