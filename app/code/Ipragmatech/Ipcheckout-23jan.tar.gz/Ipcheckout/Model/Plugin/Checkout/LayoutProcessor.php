<?php

 namespace Ipragmatech\Ipcheckout\Model\Plugin\Checkout;
 class LayoutProcessor
 {
      /**
      * @param \Magento\Checkout\Block\Checkout\LayoutProcessor $subject
      * @param array $jsLayout
      * @return array
      */
      public function afterProcess(
          \Magento\Checkout\Block\Checkout\LayoutProcessor $subject,
          array  $jsLayout
      ) {

          $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/otp.log');
          $logger = new \Zend\Log\Logger();
          $logger->addWriter($writer);
          $logger->info("layout Processor");


        $om = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $om->get('Magento\Customer\Model\Session');
        //$patientData = $customerSession->getPatients();
        $patientData = $customerSession->getCurrentPatients();
        $mobileNo = $customerSession->getMobileNumber();
        //$logger->info("Mobile NO: ".$mobileNo);
        //$logger->info(json_encode($patientData));

        $cityCollection = $om->get('Ipragmatech\Ipcheckout\Model\City')->getCollection();
        $cityCollection->addFieldToSelect('city_name');
        $cityCollection->addFieldToSelect('city_code');
        //$logger->info('City Select Query'. $cityCollection->getSelect());

        $cityOption = [];
        if(count($cityCollection)){
            foreach ($cityCollection as $city) {
                $temp = [
                    'value' => $city['city_name'],
                    'label' => $city['city_code']
                ];
                $cityOption[] = $temp;
            }

        }

        //Reset
        unset($jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
        ['shippingAddress']['children']['shipping-address-fieldset']['children']['city']);

         $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
         ['shippingAddress']['children']['shipping-address-fieldset']['children']['max_city_id'] = [
         'component' => 'Magento_Ui/js/form/element/select',
         'config'	=> [
         	'customScope' => 'shippingAddress.custom_attributes',
         	'template' => 'ui/form/field',
         	'elementTmpl' => 'ui/form/element/select',
         	'options' => [
                 ['value' => '11', 'label' => 'Delhi'],
                 ['value' => '12', 'label' => 'Noida'],
                 ['value' => '13', 'label' => 'Gurugram']
             ],
         	'id' => 'maxcity'
         ],
         'validation' => [
            'required-entry' => true
         ],
         'options' => [
             ['value' => '11', 'label' => 'Delhi'],
             ['value' => '12', 'label' => 'Noida'],
             ['value' => '13', 'label' => 'Gurugram']
         ],
         'label' => __('City'),
         'required' => true,
         'dataScope' => 'shippingAddress.custom_attributes.max_city_id',
         'provider' => 'checkoutProvider',
         'visible' => false,
         'sortOrder' => 56,
         'id' => 'maxcity'
         ];

         //reset city
         $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
         ['shippingAddress']['children']['shipping-address-fieldset']['children']['city'] = [
         'component' => 'Magento_Ui/js/form/element/select',
         'config'	=> [
         	'customScope' => 'shippingAddress',
         	'template' => 'ui/form/field',
         	'elementTmpl' => 'ui/form/element/select',
         	'options' => $cityOption,
         	'id' => 'maxcity'
         ],
         'validation' => [
            'required-entry' => true
         ],
         'options' => $cityOption,
         'label' => __('City'),
         'required' => true,
         'dataScope' => 'shippingAddress.city',
         'provider' => 'checkoutProvider',
         'visible' => true,
         'sortOrder' => 56,
         'id' => 'maxcity'
         ];

         $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
         ['shippingAddress']['children']['shipping-address-fieldset']['children']['max_gender'] = [
         'component' => 'Magento_Ui/js/form/element/select',
         'config'	=> [
         	'customScope' => 'shippingAddress.custom_attributes',
         	'template' => 'ui/form/field',
         	'elementTmpl' => 'ui/form/element/select',
         	'options' => [
                 ['value' => '1', 'label' => 'Male'],
                 ['value' => '2', 'label' => 'Female'],
                 ['value' => '3', 'label' => 'Others']
             ],
         	'id' => 'maxgender'
         ],
         'validation' => [
            'required-entry' => true
         ],
         'options' => [
             ['value' => '1', 'label' => 'Male'],
             ['value' => '2', 'label' => 'Female'],
             ['value' => '3', 'label' => 'Others']
         ],
         'label' => __('Gender'),
         'required' => true,
         'dataScope' => 'shippingAddress.custom_attributes.max_gender',
         'provider' => 'checkoutProvider',
         'visible' => true,
         'sortOrder' => 59,
         'id' => 'maxgender'
         ];

         $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
         ['shippingAddress']['children']['shipping-address-fieldset']['children']['max_dob'] = [
         'component' => 'Magento_Ui/js/form/element/abstract',
         'config'	=> [
         	'customScope' => 'shippingAddress.custom_attributes',
         	'template' => 'ui/form/field',
         	'elementTmpl' => 'ui/form/element/date',
         	'id' => 'maxdob',
             'options' => [],
         ],
         'validation' => [
            'required-entry' => true
         ],
         'label' => __('Date of Birth'),
         'required' => true,
         'dataScope' => 'shippingAddress.custom_attributes.max_dob',
         'provider' => 'checkoutProvider',
         'visible' => true,
         'sortOrder' => 58,
         'id' => 'maxdob'
         ];

         $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
         ['shippingAddress']['children']['shipping-address-fieldset']['children']['max_id'] = [
         'component' => 'Magento_Ui/js/form/element/abstract',
         'config'	=> [
         	'customScope' => 'shippingAddress.custom_attributes',
         	'template' => 'ui/form/field',
         // 	'elementTmpl' => 'ui/form/element/date',
         	'id' => 'max-id',
             'options' => [],
         ],
         'validation' => [
            'required-entry' => true
         ],
         'label' => __('Max ID'),
         'required' => false,
         'dataScope' => 'shippingAddress.custom_attributes.max_id',
         'provider' => 'checkoutProvider',
         'visible' => false,
         'sortOrder' => 57,
         'id' => 'max-id'
         ];


         $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
         ['shippingAddress']['children']['shipping-address-fieldset']['children']['max_city_name'] = [
         'component' => 'Magento_Ui/js/form/element/abstract',
         'config'	=> [
         	'customScope' => 'shippingAddress.custom_attributes',
         	'template' => 'ui/form/field',
         // 	'elementTmpl' => 'ui/form/element/date',
         	'id' => 'max-city-name',
             'options' => [],
         ],
         'validation' => [
            'required-entry' => true
         ],
         'label' => __('Max City'),
         'required' => false,
         'dataScope' => 'shippingAddress.custom_attributes.max_city_name',
         'provider' => 'checkoutProvider',
         'visible' => false,
         'sortOrder' => 52,
         'id' => 'max-city-name'
         ];

         $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
         ['shippingAddress']['children']['shipping-address-fieldset']['children']['country_id']['visible'] = false;

         //Unset fields
         unset($jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
         ['shippingAddress']['children']['shipping-address-fieldset']['children']['company']); //%path_to_target_node% is the path to the component's node in checkout_index_index.xml
        //  unset($jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
        //  ['shippingAddress']['children']['shipping-address-fieldset']['children']['city']); //%path_to_target_node% is the path to the component's node in checkout_index_index.xml

        // if($mobileNo){
        //     $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
        //     ['shippingAddress']['children']['shipping-address-fieldset']['children']['telephone']['value'] = $mobileNo;
        // }
        $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
        ['shippingAddress']['children']['shipping-address-fieldset']['children']['telephone']['disabled'] = 'disabled';
        // $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
        // ['shippingAddress']['children']['shipping-address-fieldset']['children']['telephone']['config']['readonly'] = true;;

        // if($patientData.MaxID){
        //     $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
        //     ['shippingAddress']['children']['shipping-address-fieldset']['children']['max_id']['value'] = $patientData.MaxID;
        // }
        // if($patientData.DateOfBirth){
        //     $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
        //     ['shippingAddress']['children']['shipping-address-fieldset']['children']['max_dob']['value'] = $patientData.DateOfBirth;
        // }
        // if($patientData.EmailID){
        //     $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
        //     ['shippingAddress']['children']['shipping-address-fieldset']['children']['email']['value'] = $patientData.EmailID;
        // }
        // if($patientData.GenderID){
        //     $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
        //     ['shippingAddress']['children']['shipping-address-fieldset']['children']['max_gender']['value'] = $patientData.GenderID;
        // }

        return $jsLayout;

      }
  }
