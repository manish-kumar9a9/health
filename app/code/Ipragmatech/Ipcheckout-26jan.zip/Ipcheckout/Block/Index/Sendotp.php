<?php
/**
 * Copyright © 2015 Ipragmatech . All rights reserved.
 */
namespace Ipragmatech\Ipcheckout\Block\Index;
use Ipragmatech\Ipcheckout\Block\BaseBlock;
class Sendotp extends BaseBlock
{
	public $hello='Hello World';
	
}
